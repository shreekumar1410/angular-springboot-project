import { Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';
import { ProfileGuard } from './guards/profile.guard';
import { RoleGuard } from './guards/role.guard';
import { LoginGuard } from './guards/login.guard';

export const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', loadComponent: () => import('./components/login/login.component').then(m => m.LoginComponent), canActivate: [LoginGuard] },
  { path: 'register-login', loadComponent: () => import('./components/register-login/register-login.component').then(m => m.RegisterLoginComponent) },
  { path: 'forgot-password', loadComponent: () => import('./components/forgot-password/forgot-password.component').then(m => m.ForgotPasswordComponent) },
  
  // Profile routes (accessible to all authenticated users)
  { path: 'profile', loadComponent: () => import('./components/profile/profile.component').then(m => m.ProfileComponent), canActivate: [AuthGuard] },
  { path: 'profile/form', loadComponent: () => import('./components/profile-form/profile-form.component').then(m => m.ProfileFormComponent), canActivate: [AuthGuard] },
  { path: 'profile/change-password', loadComponent: () => import('./components/change-password/change-password.component').then(m => m.ChangePasswordComponent), canActivate: [AuthGuard] },
  
  // USER role routes
  { path: 'user/dashboard', loadComponent: () => import('./components/dashboard/dashboard.component').then(m => m.DashboardComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'USER' } },
  { path: 'user/profile', loadComponent: () => import('./components/profile/profile.component').then(m => m.ProfileComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'USER' } },
  { path: 'users', loadComponent: () => import('./components/users-list/users-list.component').then(m => m.UsersListComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'USER' } },
  
  // EDITOR role routes
  { path: 'editor/dashboard', loadComponent: () => import('./components/dashboard/dashboard.component').then(m => m.DashboardComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'EDITOR' } },
  { path: 'editor/profile', loadComponent: () => import('./components/profile/profile.component').then(m => m.ProfileComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'EDITOR' } },
  { path: 'editor/users', loadComponent: () => import('./components/users-list/users-list.component').then(m => m.UsersListComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'EDITOR' } },
  { path: 'editor/auth-users', loadComponent: () => import('./components/auth-users/auth-users.component').then(m => m.AuthUsersComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'EDITOR' } },
  { path: 'editor/profile-create/:authId', loadComponent: () => import('./components/profile-form/profile-form.component').then(m => m.ProfileFormComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'EDITOR' } },
  { path: 'editor/profile-edit/:userId', loadComponent: () => import('./components/profile-form/profile-form.component').then(m => m.ProfileFormComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'EDITOR' } },
  
  // SUPPORT role routes
  { path: 'support/dashboard', loadComponent: () => import('./components/dashboard/dashboard.component').then(m => m.DashboardComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'SUPPORT' } },
  { path: 'support/profile', loadComponent: () => import('./components/profile/profile.component').then(m => m.ProfileComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'SUPPORT' } },
  { path: 'support/users', loadComponent: () => import('./components/users-list/users-list.component').then(m => m.UsersListComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'SUPPORT' } },
  { path: 'support/password-reset-requests', loadComponent: () => import('./components/support-password-reset-requests/support-password-reset-requests.component').then(m => m.SupportPasswordResetRequestsComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'SUPPORT' } },
  { path: 'support/login-audit', loadComponent: () => import('./components/login-audit/login-audit.component').then(m => m.LoginAuditComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'SUPPORT' } },
  
  // ADMIN role routes
  { path: 'admin/dashboard', loadComponent: () => import('./components/dashboard/dashboard.component').then(m => m.DashboardComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'ADMIN' } },
  { path: 'admin/profile', loadComponent: () => import('./components/profile/profile.component').then(m => m.ProfileComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'ADMIN' } },
  { path: 'admin/users', loadComponent: () => import('./components/users-list/users-list.component').then(m => m.UsersListComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'ADMIN' } },
  { path: 'admin/auth-users', loadComponent: () => import('./components/auth-users/auth-users.component').then(m => m.AuthUsersComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'ADMIN' } },
  { path: 'admin/password-reset-audit', loadComponent: () => import('./components/password-reset-audit/password-reset-audit.component').then(m => m.PasswordResetAuditComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'ADMIN' } },
  
  // SUPER_ADMIN role routes
  { path: 'super-admin/dashboard', loadComponent: () => import('./components/dashboard/dashboard.component').then(m => m.DashboardComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'SUPER_ADMIN' } },
  { path: 'super-admin/profile', loadComponent: () => import('./components/profile/profile.component').then(m => m.ProfileComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'SUPER_ADMIN' } },
  { path: 'super-admin/users', loadComponent: () => import('./components/users-list/users-list.component').then(m => m.UsersListComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'SUPER_ADMIN' } },
  { path: 'super-admin/roles', loadComponent: () => import('./components/auth-users/auth-users.component').then(m => m.AuthUsersComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'SUPER_ADMIN' } },
  { path: 'super-admin/password-reset-audit', loadComponent: () => import('./components/password-reset-audit/password-reset-audit.component').then(m => m.PasswordResetAuditComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'SUPER_ADMIN' } },
  { path: 'super-admin/login-audit', loadComponent: () => import('./components/login-audit/login-audit.component').then(m => m.LoginAuditComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'SUPER_ADMIN' } },
  { path: 'super-admin/action-audit', loadComponent: () => import('./components/super-admin-action-audit/super-admin-action-audit.component').then(m => m.SuperAdminActionAuditComponent), canActivate: [AuthGuard, ProfileGuard, RoleGuard], data: { role: 'SUPER_ADMIN' } },
];
