package com.example.registration.enums;

public enum LoginAlertType {
    FIRST_LOGIN,
    NORMAL,
    SESSION_TIMEOUT
}
