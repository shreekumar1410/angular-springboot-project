package com.example.registration.enums;

public enum ActionStatus {
    SUCCESS,
    FAILED
}
