package com.example.registration.enums;

public enum PasswordResetStatus {
    REQUESTED,
    ACCEPTED,
    PASSWORD_SENT
}
