package com.example.registration.enums;

public enum Roles {

        USER,
        EDITOR,
        SUPPORT,
        ADMIN,
        SUPER_ADMIN,
        SYSTEM


}
