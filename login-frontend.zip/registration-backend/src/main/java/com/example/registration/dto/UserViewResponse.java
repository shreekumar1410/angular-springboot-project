package com.example.registration.dto;

public interface UserViewResponse {
}
