package com.example.registration.enums;

public enum LoginType {
    LOGIN,
    LOGOUT,
    FAILED,
    PASSWORD_CHANGED,
    PASSWORD_RESET_BY_SUPPORT
}
